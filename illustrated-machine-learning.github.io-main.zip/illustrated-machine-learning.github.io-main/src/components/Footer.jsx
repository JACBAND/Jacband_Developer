import './Footer.css';

export default function Footer() {
    return (
        <footer>Copyright &copy;2023</footer>
    );
}