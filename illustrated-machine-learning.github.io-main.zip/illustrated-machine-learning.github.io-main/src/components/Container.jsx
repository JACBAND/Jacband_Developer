import '../pages/Page.css';

export default function Container(template) {
    return (
        <div className="chapter-container">
            {template}
        </div>
    );
}